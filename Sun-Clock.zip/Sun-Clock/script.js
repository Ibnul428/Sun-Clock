function updateClock() {
  const now = new Date();
  const hours = now.getHours() + now.getMinutes() / 60;

  document.getElementById("time").textContent = now.toLocaleTimeString();

  const sun = document.querySelector(".sun");
  const clock = document.querySelector(".clock");
  const width = clock.clientWidth;
  const height = clock.clientHeight / 2;

  const angle = (hours / 24) * 2 * Math.PI;
  const x = width * (hours / 24);
  const y = height - Math.sin(angle) * height;

  sun.style.left = `${x - 25}px`;
  sun.style.top = `${y - 25}px`;
}

setInterval(updateClock, 1000);
updateClock();
